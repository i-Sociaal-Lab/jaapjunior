---
document: Overeenkomst Wmo
versie: "1.3"
artikel: "3.21"
bron: CSW_Overeenkomst_Wmo_1.3.md
bronstatus: primaire bron
---

# Artikel 3.21 – Financiële verantwoordelijkheid

## Bronvermelding

Dit bestand bevat de tekst van artikel 3.21 uit de primaire bron **CSW_Overeenkomst_Wmo_1.3.md**, versie 1.3.

## Contracttekst

## Artikel 3.21 – Financiële verantwoordelijkheid

### Mogelijke chatbotvragen

- Wat staat er in artikel 3.21 over financiële verantwoordelijkheid?
- Wat bepaalt artikel 3.21?

### Brontekst

**Artikel 3.21 – Financiële verantwoordelijkheid**

3.21.1
Opdrachtnemer staat niet garant voor derden, tenzij Opdrachtgever daarvoor vooraf schriftelijke toestemming geeft.

3.21.2
Als Opdrachtgever een voorschot betaalt, dan mag hij dit op elk moment terugvragen of verrekenen.

3.21.3
Als iemand beslag legt op geld van Opdrachtnemer bij Opdrachtgever (derdenbeslag), dan mag Opdrachtgever de kosten die hierdoor ontstaan verhalen op Opdrachtnemer.
