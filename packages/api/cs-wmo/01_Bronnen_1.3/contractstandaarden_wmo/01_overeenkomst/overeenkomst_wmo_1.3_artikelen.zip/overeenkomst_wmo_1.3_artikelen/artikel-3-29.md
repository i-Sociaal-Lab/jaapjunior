---
document: Overeenkomst Wmo
versie: "1.3"
artikel: "3.29"
bron: CSW_Overeenkomst_Wmo_1.3.md
bronstatus: primaire bron
---

# Artikel 3.29 – Wijzigen van omstandigheden

## Bronvermelding

Dit bestand bevat de tekst van artikel 3.29 uit de primaire bron **CSW_Overeenkomst_Wmo_1.3.md**, versie 1.3.

## Contracttekst

## Artikel 3.29 – Wijzigen van omstandigheden

### Mogelijke chatbotvragen

- Wat staat er in artikel 3.29 over wijzigen van omstandigheden?
- Wat bepaalt artikel 3.29?

### Brontekst

**Artikel 3.29 – Wijzigen van omstandigheden**

3.29.1
Als er iets belangrijks verandert dat invloed heeft op deze overeenkomst, dan informeren Partijen elkaar daar terstond over.

Opdrachtnemer meldt altijd:
– veranderingen in zijn organisatie (bijvoorbeeld rechtsvorm),
– veranderingen bij bestuurders,
– stopzetten van garanties,
– nieuwe of beëindigde deelnemingen.

3.29.2
Als de wet (bijvoorbeeld de Wmo 2015) verandert waardoor de afgesproken maatschappelijke ondersteuning niet meer vergoed wordt, dan stopt dat deel van de overeenkomst automatisch, vanaf de datum waarop de wijziging ingaat. Opdrachtgever hoeft in dat geval geen schadevergoeding te betalen.
