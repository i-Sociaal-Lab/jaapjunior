---
document: Overeenkomst Wmo
versie: "1.3"
artikel: "3.15"
bron: CSW_Overeenkomst_Wmo_1.3.md
bronstatus: primaire bron
---

# Artikel 3.15 – UBO (Ultimate Beneficial Owner)

## Bronvermelding

Dit bestand bevat de tekst van artikel 3.15 uit de primaire bron **CSW_Overeenkomst_Wmo_1.3.md**, versie 1.3.

## Contracttekst

## Artikel 3.15 – UBO (Ultimate Beneficial Owner)

### Mogelijke chatbotvragen

- Wat staat er in artikel 3.15 over ubo (ultimate beneficial owner)?
- Wat bepaalt artikel 3.15?

### Brontekst

**Artikel 3.15 – UBO (Ultimate Beneficial Owner)**


**3.15.1**

De Aanbieder heeft geen UBO('s) die valt/vallen onder een wettelijke sanctieregeling zoals bedoeld in lid 2.


**3.15.2**

Onverminderd hetgeen bepaald is in lid 1, betaalt de Opdrachtgever nooit aan een Opdrachtnemer waarvan de UBO('s) is/zijn vermeld op een sanctielijst behorend bij de Sanctiewet en -regelgeving. Om dit te kunnen controleren, maakt de Opdrachtgever onder andere gebruik van het landelijk UBO-register. De Opdrachtnemer draagt daartoe – als voor hem een registratieplicht geldt – zorg voor een juiste UBO-registratie in het landelijk UBO-register. Mocht de Opdrachtgever de UBO(’s) niet zelf – onder andere door gebruikmaking van het landelijk UBO-register – kunnen vaststellen, dan verstrekt de Opdrachtnemer op eerste verzoek van de Opdrachtgever deze informatie aan de Opdrachtgever.

3.15.3.

Onverminderd de geldigheid van deze overeenkomst betaalt de Opdrachtgever nooit aan een Opdrachtnemer die zijn UBO niet bekend maakt of waarvan een UBO onder een wettelijke sanctieregeling valt.


**3.15.4**

Indien de Opdrachtgever de UBO('s) van de Opdrachtnemer niet kan achterhalen en de Opdrachtnemer na het eerste verzoek van de Opdrachtgever geen informatie verstrekt over de UBO('s) zoals bedoeld in lid 2, dan heeft de Opdrachtgever de mogelijkheid om betalingen aan de Aanbieder op te schorten totdat de Opdrachtgever toereikende informatie over de UBO('s) van de Opdrachtnemer heeft verkregen.
