---
document: Overeenkomst Wmo
versie: "1.3"
artikel: "3.19"
bron: CSW_Overeenkomst_Wmo_1.3.md
bronstatus: primaire bron
---

# Artikel 3.19 – Niet-nakoming, opzegging en ontbinding

## Bronvermelding

Dit bestand bevat de tekst van artikel 3.19 uit de primaire bron **CSW_Overeenkomst_Wmo_1.3.md**, versie 1.3.

## Contracttekst

## Artikel 3.19 – Niet-nakoming, opzegging en ontbinding

### Mogelijke chatbotvragen

- Wat staat er in artikel 3.19 over niet-nakoming, opzegging en ontbinding?
- Wat bepaalt artikel 3.19?

### Brontekst

**Artikel 3.19 – Niet-nakoming, opzegging en ontbinding**

3.19.1
Als Opdrachtnemer zijn afspraken niet nakomt, dan mag Opdrachtgever maatregelen nemen om dat te herstellen.

(Bij inspanningsgerichte en outputgerichte uitvoering:) Opdrachtgever kan:
– prestaties en tarieven tijdelijk aanpassen
– onterecht betaalde bedragen terugvorderen of verrekenen
– tijdelijk 5% korting geven op het tarief
– de overeenkomst opzeggen

(Bij taakgerichte uitvoering:) Opdrachtgever kan:
– prestaties en budget tijdelijk aanpassen
– onterecht besteed budget terugvorderen of verrekenen
– tijdelijk 5% korting geven op het budget
– de overeenkomst opzeggen

3.19.2
Als Opdrachtnemer tekortschiet, moet hij schade aan Opdrachtgever en cliënten vergoeden.  Opdrachtgever moet wel proberen de schade te beperken. Opdrachtnemer blijft de ondersteuning goed uitvoeren.

3.19.3
Als Opdrachtnemer onjuiste of onvolledige informatie tijdens de inkoopprocedure geeft, dan geldt dat als een tekortkoming in de nakoming van deze overeenkomst.

3.19.4
Opdrachtgever mag de overeenkomst meteen en zonder rechter ontbinden als:

a) een uitsluitingsgrond van toepassing is of Opdrachtnemer niet meer aan (geschiktheids)eisen voldoet
b) Opdrachtnemer 12 kalendermaanden geen ondersteuning levert of declareert
c) Opdrachtnemer een opgelegde herstelsanctie niet uitvoert
d) de kwaliteit van de ondersteuning ernstig tekortschiet, ook na een herstelpoging
e) er bewezen fraude is of sprake van een ander strafbaar feit.

f) Opdrachtgever op basis van eigen onderzoek op grond van de Wet Bibob een negatieve conclusie trekt over Opdrachtnemer, de combinant, een onderaannemer en/of een of meer vertegenwoordigers van deze partijen, zoals bestuurders of toezichthouders, met inachtneming van het begrip 'betrokkene' uit de Wet Bibob;

g) het Landelijk Bureau Bibob een negatief advies uitbrengt over Opdrachtnemer, de combinant, een onderaannemer en/of een of meer vertegenwoordigers van deze partijen, met inachtneming van het begrip ‘betrokkene’ uit de Wet Bibob;

h) Opdrachtnemer, de combinant, een onderaannemer en/of een of meer vertegenwoordigers van deze partijen de gevraagde informatie niet, niet volledig of niet op tijd leveren aan Opdrachtgever en/of het Landelijk Bureau Bibob;

i) een instantie een bestuurlijke boete oplegt, waaronder een fiscale vergrijpboete.

3.19.5
Bij overmacht die langer dan 30 kalenderdagen duurt, mogen Partijen de overeenkomst (deels) beëindigen zonder tussenkomst van de rechter.

3.19.6
Als de overeenkomst stopt of Opdrachtnemer met zijn werk stopt, dan zorgt Opdrachtnemer voor een goede overdracht van de cliënten, met toestemming van Opdrachtgever. Op verzoek stuurt hij direct een lijst met klantgegevens, waarbij hij rekening houdt met de privacyregels. Als er geen overdracht kan plaatsvinden, dan blijven de prestaties en tarieven gelden.


# Hoofdstuk 7: Slotbepalingen
